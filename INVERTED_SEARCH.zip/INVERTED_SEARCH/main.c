/*Name:G.Haritha
Date:23/11/24
Description:inverted searched header file.*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"
// Main function
int main(int argc, char *argv[]) 
{
    printf("\n");
    // Check if no arguments are provided
    if (argc < 2) 
    {
        printf("\n----------------------------------------------------\n\n");
        printf("ERROR : ./a.out          : INVALID ARGUMENTS\n\nUSAGE :\n");
        printf("provide CLA as           : ./a.out filename1.txt filename2.txt filename3.txt...<files> \n");
        printf("------------------------------------------------------\n\n");
        return 0;
    }

    filenode *File_name = NULL;
    filenode *dupli_filename = NULL;
    mainlist *hashtable[27] = {NULL};

    validate_files(argc, argv, &File_name);
    // Print the list of valid files
    print_file_list(File_name);

    int choice;
    char search_word[50], backup_file[50], backup_file_name[50];
    
    while (1)
    {
        printf("\n\nSelect your choice among the following options:\n\n");
        printf("1. CREATE DATABASE\n");
        printf("2. DISPLAY DATABASE\n");
        printf("3. SREACH DATABASE\n");
        printf("4. UPDATE DATABASE\n");
        printf("5. SAVE DATABASE\n");
        printf("6. Exit\n\n");
        printf("Enter the choice: ");
        scanf("%d", &choice);
        getchar();  // To consume the newline character left by scanf
        printf("\n\n");

        switch(choice)
        {
            case 1:

                if(create_database(File_name,hashtable,dupli_filename) == SUCCESS)
		        {
                    printf("INFO : Database creation is successful.");
		        }
                else
		        {
                    printf("INFO : Database is already created.Only one time cretion is Possible.\n\n");
		        }
                break;

            case 2:

                if(display_database(hashtable) == SUCCESS)
		        {
                    printf("INFO : Displayed successfully.");
		        }
                else
		        {
                    printf("INFO : Database not created, first you create database.\n");
		        }
                break;

            case 3:

                printf("Enter the word to search: ");
                scanf("%s", search_word); // Read the input into search_word
                printf("\n");

                if(search_database(hashtable,search_word) == SUCCESS)
		        {
                    printf("INFO : Search data successful.\n\n");
		        }
                else if(search_database(hashtable, search_word) == FAILURE)
		        {
                    printf("INFO : Word %s is not present in Database.\n\n", search_word);
		        }
		        else
		        {
		            printf("INFO : Database is empty, first you create database. \n");
		        }
                break;

            case 4:

                printf("Enter the backup file name : ");
                scanf("%s", backup_file_name);
                printf("\n\n");

                int update_status = update_database(hashtable,backup_file_name,&dupli_filename);
                if(update_status == SUCCESS)
		        {
                    printf("INFO : Update data is successful.\n\n");
		        }
                else if(update_status == FAILURE)
		        {
                    printf("INFO : Database is not empty, update data not possible.\n\n");
		        }
                else if(update_status == NOT_TXT_FILE)
		        {
        	      printf("INFO : FILE %s is not a txt file, so file is not a backup file\n", backup_file_name);
		        }
                break;

            case 5:

                printf("Enter the backup file name : ");
                scanf("%s", backup_file);
                printf("\n\n");

                if(save_database(hashtable,backup_file) == SUCCESS)
		        {
                    printf("INFO : DATA saved successfully.\n\n");
		        }
                else if(save_database(hashtable,backup_file) == FAILURE)
		        {
                    printf("INFO : DATA save not successful.\n\n");
		        }
                else if(save_database(hashtable, backup_file) == EMPTY_DATABASE)
		        {
		          printf("INFO : Database is empty, first you create database.\n");
		        }
                else if(save_database(hashtable, backup_file) == NOT_TXT_FILE)
		        {
        	        printf("INFO : FILE %s is not a txt file, so this file is not considered\n", backup_file);
		        }
                break;

            case 6:

                printf("Exiting...\n");
                return 0;

            default:

                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
void validate_files(int argc, char *argv[], filenode **File_name)
{
    for (int i = 1; i < argc; i++)
    {
        FILE *file = fopen(argv[i], "r");
        if (file == NULL)
        {
            printf("INFO : FILE %s does not exist, so this file is not considered\n", argv[i]);
            continue;
        }
        if (is_file_txt(argv[i]) == 1)
        {
            printf("INFO : FILE %s is not a txt file, so this file is not considered\n", argv[i]);
            continue;
        }
        if (is_file_empty(argv[i]))
        {
            printf("INFO : FILE %s is empty, so this file is not considered\n", argv[i]);
            continue;
        }
        if(insert_file(File_name, argv[i])==2)
            printf("INFO : FILE %s already present, so this file is not considered\n", argv[i]);
        fclose(file);
    }
    if(*File_name == NULL)
    {
        printf("No valid files\n");
        exit(1);
    }
}

// Insert file into the list
int insert_file(filenode **File_name, const char *filename)
{
    if (is_duplicate(*File_name, filename))
    {
       // printf("INFO : FILE %s already present, so this file is not considered\n", filename);
        return 2; // Indicate that the file is a duplicate
    }

    filenode *new_node = (filenode *)malloc(sizeof(filenode));
    if (new_node == NULL)
    {
        perror("Failed to allocate memory");
        exit(EXIT_FAILURE);
    }
    strcpy(new_node->data, filename);
    new_node->link = NULL;

    if(*File_name == NULL)
    {
        *File_name = new_node;
    }
    else
    {
        filenode *temp = *File_name;
        while(temp->link)
            temp = temp->link;

        temp->link = new_node;
    }
    return 0; // Successfully inserted
}

// Check for duplicates
int is_duplicate(filenode *File_name, const char *filename)
{
    while (File_name != NULL)
    {
        if (strcmp(File_name->data, filename) == 0)
        {
            return 1; // Found a duplicate
        }
        File_name = File_name->link;
    }
    return 0; // No duplicates found
}

// Print the list of valid files
void print_file_list(filenode *File_name)
{
    printf("\nList of valid files: ");
    while (File_name != NULL)
    {
        if(File_name->link)
            printf("%s, ", File_name->data);
        else
            printf("%s ", File_name->data);
        File_name = File_name->link;
    }
}

// Check if file is empty
int is_file_empty(const char *filename)
{
    FILE *file = fopen(filename, "r");
    if (file == NULL)
    {
        return 0;
    }
    int c = fgetc(file);
    if (c == EOF)
    {
        fclose(file);
        return 1; // File is empty
    }
    fclose(file);
    return 0; // File is not empty
}

/*function defintion of txt file*/
int is_file_txt(const char *filename)
{
    if(strchr(filename, '.') == NULL)
        return 1;
    if(strcmp(strchr(filename, '.'), ".txt") == 0)
        return 0;
    else
        return 1;
}