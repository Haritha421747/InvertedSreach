/*Name:G.Haritha
Date:23/11/24
Description:inverted searched header file.*/
#ifndef HEADER_H
#define HEADER_H

#define SUCCESS 0
#define FAILURE 1
#define EMPTY_DATABASE 2
#define NOT_TXT_FILE 5
#define size 27

// Define the structures
typedef struct subnode 
{
    int word_count;
    char filename[50];
    struct subnode *sublink;
} sublist;

typedef struct mainnode 
{
    int file_count;
    char word[100];
    struct subnode *sublink;
    struct mainnode *mainlink;
} mainlist;

typedef struct filename 
{
    char data[100];
    struct filename *link;
}filenode;

// Function prototypes
void validate_files(int argc, char *argv[],filenode **File_name);

int is_file_txt(const char *filename);

int insert_file(filenode **File_name, const char *filename);
void print_file_list(filenode *File_name);

int is_file_empty(const char *filename);
int is_duplicate(filenode *File_name, const char *filename);
 

int create_database(filenode *File_name,mainlist *hashtable[],filenode *dupli_filename);
int find_index_key(const char *ch);

int display_database(mainlist *hashtable[]);

int search_database(mainlist *hastable[],const char *word);

int save_database(mainlist *hashtable[], const char *word);

int update_database(mainlist *hashtable[], const char *word, filenode **dupli_filename);
int check_file_updated(const char *filename,filenode *dupli_filename);

#endif