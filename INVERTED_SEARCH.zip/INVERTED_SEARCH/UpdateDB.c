/*Name:G.Haritha
Date:3/12/24
Description:inverted search updatedatabase file.*/
#include <stdio.h>     
#include <stdlib.h>     
#include <string.h>     
#include "header.h"       
    

// Function to update the database from a backup file
int update_database(mainlist *hashtable[], const char *word,filenode **dupli_filename) 
{
    if (is_file_txt(word) == 1) 
    {
        return NOT_TXT_FILE;
    }

    char str[150];  // Buffer to store strings from the file
    FILE *fptr = fopen(word, "r");  // Open the backup file for reading
    if (fptr == NULL) {
        printf("INFO : FILE %s does not exist.\n", word);
        return -1;
    }

    // Read the file line by line
    while (fscanf(fptr, "%149s", str) == 1) {
        // Check if the line starts with '#'
        if (str[0] != '#') {
            printf("INFO : The file provided is not a backup file.\n");
            fclose(fptr);
            return -1;
        }

        // Tokenize the string and get the index directly from the first part
        char *token = strtok(str, "#;");
        int index = -1;

        // Try to parse the first token as an integer index (e.g., [1])
        if (token[0] == '[') {
            token++;  // Skip the '[' character
            if (token[strlen(token) - 1] == ']') 
            {
                token[strlen(token) - 1] = '\0';  // Remove the closing ']' character
            }
            index = atoi(token);  // Convert the token to an integer index
        }

        // Ensure index is valid
        if (index < 0) {
            printf("INFO : Invalid index for word %s\n", token);
            fclose(fptr);
            return -1;
        }

        // Check if the index already exists in the array
        if (hashtable[index] == NULL) {
            // Create a new mainlist node if index doesn't exist
            mainlist *new_main = malloc(sizeof(mainlist));
            if (new_main == NULL) 
            {
                perror("Failed to allocate memory");
                fclose(fptr);
                return FAILURE;
            }

            // Copy the word and file count
            strcpy(new_main->word, strtok(NULL, "#;"));
            token = strtok(NULL, "#;");
            new_main->file_count = atoi(token);
            new_main->sublink = NULL;
            new_main->mainlink = NULL;
            hashtable[index] = new_main;  // Assign the new node to the array

            // Iterate through the file count to add sublist nodes
            for (int i = 0; i < new_main->file_count; i++) {
                sublist *new_sub = malloc(sizeof(sublist));
                if (new_sub == NULL) {
                    perror("Failed to allocate memory");
                    fclose(fptr);
                    return FAILURE;
                }

                // Add the new sublist node to the mainlist node
                if (new_main->sublink == NULL) {
                    new_main->sublink = new_sub;
                } else {
                    sublist *temp = new_main->sublink;
                    while (temp->sublink) {
                        temp = temp->sublink;
                    }
                    temp->sublink = new_sub;
                }

                // Copy filename and word count to the sublist node
                strcpy(new_sub->filename, strtok(NULL, "#;"));
                insert_file(dupli_filename, new_sub->filename); // Insert filename into duplicate filename list
                token = strtok(NULL, "#;");
                new_sub->word_count = atoi(token);
                new_sub->sublink = NULL;  // Initialize sublink to NULL
            }
        } else {
            // If index exists, update it
            printf("INFO : Index %d already exists. Updating...\n", index);
            mainlist *existing_main = hashtable[index];

            // Update the word and file count of the existing mainlist entry
            strcpy(existing_main->word, strtok(NULL, "#;"));
            token = strtok(NULL, "#;");
            existing_main->file_count = atoi(token);
        }
    }

    fclose(fptr);
    return SUCCESS;
}