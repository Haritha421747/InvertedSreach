/*Name:G.Haritha
Date:26/11/24
Description:inverted search savadatabase file.*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"          

// Function to save the database to a file
int save_database(mainlist *hashtable[], const char *word)
{
    int display_count = 0, i = 0;   // Count non-NULL entries in the array
    for (i = 0; i < 27; i++)
    {
        if (hashtable[i] != NULL)
        {
            display_count++; 
        }
    }   
    // check hashtable is empty or not.                           
    if (display_count == 0)
    {
        return EMPTY_DATABASE; 
    }
    if (is_file_txt(word) == 1)
    {
        return NOT_TXT_FILE;
    }
    // Open the file in write mode
    FILE *fptr = fopen(word, "w");  
    if (fptr == NULL)
    {
        printf("INFO : FILE %s could not be created or opened, so this file is not considered\n", word);
        return FAILURE;
    }                                // Loop through the array and write data to the file
    for (i = 0; i < size; i++)
    {
        mainlist *temp = hashtable[i];
        while (temp)
        {
            fprintf(fptr, "#[%d];%s;%d;", i, temp->word, temp->file_count);  // Write mainlist data to the .txt file
            sublist *traverse = temp->sublink;
            while (traverse)
            {
                fprintf(fptr, "%s;%d;", traverse->filename, traverse->word_count);  // Write sublist data to the .txt file
                traverse = traverse->sublink;
            }
            fprintf(fptr, "#\n");  // End of mainlist entry
            temp = temp->mainlink;
        }
    }

    fclose(fptr);  // Close the file
    return SUCCESS;  // Return SUCCESS if the database is saved successfully
}