/*NAME:G.HARITHA
DATE:4/12/24
DESCRIPTION:INVERTED SEARCH.
SAMPLEINPUT&SAMPLEOUTPUT:*/
haritha@LAPTOP-NQOEOIIB:~/INVERTED_SEARCH$ gcc *.c
haritha@LAPTOP-NQOEOIIB:~/INVERTED_SEARCH$ ./a.out


----------------------------------------------------

ERROR : ./a.out          : INVALID ARGUMENTS

USAGE :
provide CLA as           : ./a.out filename1.txt filename2.txt filename3.txt...<files> 
------------------------------------------------------

 haritha@LAPTOP-NQOEOIIB:~/INVERTED_SEARCH$ ./a.out file1.txt file2.txt file3.sh file4.txt

INFO : FILE file3.sh does not exist, so this file is not considered
INFO : FILE file4.txt does not exist, so this file is not considered

List of valid files: file1.txt, file2.txt 

Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 1


INFO : Database creation is successful.

Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 2



------------------------------------------------------------------------

Index    Word   FileCount       Filename        WordCount

------------------------------------------------------------------------

0       are             1               file2.txt       1

4       every           1               file1.txt       1

7       hi              2               file1.txt       1
                                        file2.txt       1

7       how             1               file2.txt       1

14      one             1               file1.txt       1

24      you             1               file2.txt       1

------------------------------------------------------------------------

INFO : Displayed successfully.

Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 3


Enter the word to search: apple

INFO : Word apple is not present in Database.
 

Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 3


Enter the word to search: hi

The word 'hi' is present in 2 files
file1.txt -> 1 times
file2.txt -> 1 times


INFO : Search data successful.


Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 4   

Enter the backup file name : input.sk

INFO : FILE input.sk is not a txt file, so file is not a backup file


Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 4


Enter the backup file name : input.txt

INFO : Update data is successful.
Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 2



------------------------------------------------------------------------

Index    Word   FileCount       Filename        WordCount

------------------------------------------------------------------------

0       all             1               file2.txt       1

4       every           1               file1.txt       1

7       emertxe         1               file1.txt       1
                                        file2.txt       1

7       how             1               file2.txt       1

14      one             1               file1.txt       1

24      you             1               file2.txt       1

------------------------------------------------------------------------

INFO : Displayed successfully.
 

Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 1

INFO : Database is already created.Only one time creation is Possible.
Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 5


Enter the backup file name : output.sh


INFO : FILE output.sh is not a txt file, so this file is not considered


Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 5

Enter the backup file name : output.txt

INFO : DATA saved successfully.

Select your choice among the following options:

1. CREATE DATABASE
2. DISPLAY DATABASE
3. SREACH DATABASE
4. UPDATE DATABASE
5. SAVE DATABASE
6. Exit

Enter the choice: 6


Exiting...
haritha@LAPTOP-NQOEOIIB:~/INVERTED_SEARCH$