/*Name:G.Haritha
Date:24/11/24
Description:inverted search display database file.*/
#include <stdio.h>      
#include <stdlib.h>     
#include <string.h>     
#include "header.h"       

// Function to display the database
int display_database(mainlist *hashtable[])
{
    int display_count = 0;  
    int i = 0;              

    // Loop through the array to count non-NULL entries
    for (i = 0; i < 27; i++)
    {
        if (hashtable[i] != NULL)
         display_count++;
    }
    // If the array is empty, return FAILURE
    if (display_count == 0)
        return FAILURE;
    // Print the header for the database display
    printf("\n------------------------------------------------------------------------\n\n");
    printf("Index\t Word\tFileCount\tFilename\tWordCount\n");
    printf("\n------------------------------------------------------------------------\n\n");
    int count = 0;  
    // Loop through the array to display the database
    for (i = 0; i < size; i++)
    {
        mainlist *temp =hashtable[i];  // Pointer to traverse the mainlist

        // Loop through the mainlist nodes
        while (temp)
        {
            count = 0;  // Reset count for each mainlist node
            printf("%d\t%s\t\t%d", i, temp->word, temp->file_count);

            sublist *traverse = temp->sublink;  // Pointer to traverse the sublist
            
            // Loop through the sublist nodes
            while (traverse)
            {
                if (count == 0)
		        {
                    printf("\t\t%s\t%d\n", traverse->filename, traverse->word_count);
		        }
                else
		        {
                    printf("\t\t\t\t\t%s\t%d\n", traverse->filename, traverse->word_count);
		        }

                traverse = traverse->sublink;  // Move to the next sublist node
                count++;
            }

            temp = temp->mainlink;  // Move to the next mainlist node
            printf("\n");
        }
    }

    // Print the footer for the database display
    printf("------------------------------------------------------------------------\n\n");

    // Return SUCCESS indicating the display was completed
    return SUCCESS;
}