/*Name:G.Haritha
Date:24/11/24
Description:inverted search createfile.*/
#include <stdio.h>      
#include <stdlib.h>      
#include <string.h>      
#include "header.h"        

// Function for database creation
int create_database(filenode *File_name, mainlist *hashtable[],filenode *dupli_filename)
{
    static int database_flag=0;
    if(!database_flag)	
    {
	   database_flag = 1;

      while (File_name)
      {
	    if(check_file_updated(File_name->data,dupli_filename)==FAILURE)
	    {
            File_name = File_name->link;  // Move to the next file in the file list
	        continue;
	    }

        FILE *fptr = fopen(File_name->data, "r");  // Open file for reading
        
        if (fptr == NULL)  // Check if file opening failed
        {
            perror("Failed to open file");  
            exit(EXIT_FAILURE);  
        }

        char word[50];  // Buffer to store each word read from the file

        while (fscanf(fptr, "%49s", word) == 1)  // Read words from file until end of file
        {
            int index = find_index_key(word);  // Find the hash index for the word

            if (hashtable[index] == NULL)  // Check if there is no entry at the index
            {
                mainlist *new_main = malloc(sizeof(mainlist));  // Allocate memory for new mainlist node
                if (new_main == NULL)  // Check if memory allocation failed
                {
                    perror("Failed to allocate memory");  
                    exit(EXIT_FAILURE);  
                }
                new_main->file_count = 1;  // Initialize file count
                strcpy(new_main->word, word);  // Copy word to new mainlist node
                new_main->sublink = NULL;  
                new_main->mainlink = NULL;  

                sublist *new_sub = malloc(sizeof(sublist));  // Allocate memory for new sublist node
                if (new_sub == NULL)  // Check if memory allocation failed
                {
                    perror("Failed to allocate memory");  
                    exit(EXIT_FAILURE);  
                }
                strcpy(new_sub->filename, File_name->data);  // Copy filename to new sublist node
                new_sub->word_count = 1;  // Initialize word count
                new_sub->sublink = NULL;  

                new_main->sublink = new_sub;  // Link sublist to mainlist node
                hashtable[index] = new_main;  // Insert mainlist node into hash table

            }
            else  // Handle case where there is already an entry at the index
            {
                int dupli = 1;  // Flag to check for duplicate words
                mainlist *traverse = hashtable[index];  // Pointer to traverse the mainlist
                mainlist *prev = NULL;  

                while (traverse)  // Loop through the mainlist nodes
                {
                    if (strcmp(traverse->word, word) == 0)  // Check for duplicate word
                    {
                        dupli = 0;  
                        break;  
                    }
                    prev = traverse;  // Update previous node pointer
                    traverse = traverse->mainlink;  // Move to the next mainlist node
                }

                if (dupli)  // Handle case where word is not a duplicate
                {
                    mainlist *new_main = malloc(sizeof(mainlist));  // Allocate memory for new mainlist node
                    if (!new_main)  // Check if memory allocation failed
                    {
                        perror("Failed to allocate memory");  
                        exit(EXIT_FAILURE);  
                    }
                    new_main->file_count = 1;  
                    strcpy(new_main->word, word);  
                    new_main->sublink = NULL;  
                    new_main->mainlink = NULL;  

                    sublist *new_sub = malloc(sizeof(sublist));  // Allocate memory for new sublist node
                    if (new_sub==NULL)  // Check if memory allocation failed
                    {
                        perror("Failed to allocate memory"); 
                        exit(EXIT_FAILURE);  
                    }
                    strcpy(new_sub->filename, File_name->data);  
                    new_sub->word_count = 1; 
                    new_sub->sublink = NULL;  

                    new_main->sublink = new_sub;  // Link sublist to mainlist node
                    prev->mainlink = new_main;  // Link new mainlist node to the end of the mainlist

                }
                else  // Handle case where word is a duplicate
                {
                    sublist *temp = traverse->sublink;  // Pointer to traverse the sublist
                    sublist *sub_prev = NULL;  // Pointer to keep track of the previous sublist node
                    int same_file = 0;  // Flag to check if the same file is found

                    while (temp)  // Loop through the sublist nodes
                    {
                        if (strcmp(temp->filename, File_name->data) == 0)  // Check for the same file
                        {
                            same_file = 1;  
                            temp->word_count++;  
                            break;  
                        }
                        sub_prev = temp;  // Update previous sublist node pointer
                        temp = temp->sublink;  // Move to the next sublist node
                    }

                    if (!same_file)  // Handle case where the file is not found in the sublist
                    {
                        sublist *new_sub = malloc(sizeof(sublist));  // Allocate memory for new sublist node
                        if (new_sub==NULL)  // Check if memory allocation failed
                        {
                            perror("Failed to allocate memory"); 
                            exit(EXIT_FAILURE);  
                        }
                        strcpy(new_sub->filename, File_name->data);  
                        new_sub->word_count = 1;  
                        new_sub->sublink = NULL;  

                        if (sub_prev == NULL)  // Handle case where sublist is empty
                            traverse->sublink = new_sub;  // Link new sublist node to mainlist node
                        else
                            sub_prev->sublink = new_sub;  // Link new sublist node to the end of the sublist

                    	   traverse->file_count++;  // Increment file count in mainlist node
		            }
                }
            }
        }
        fclose(fptr);  
        File_name = File_name->link;  // Move to the next file in the file list
    }
}
else
{
  return FAILURE;
}
return SUCCESS;  
}

int find_index_key(const char *ch)  // Function to find the hash index for a given word
{
    int index;  
    if (*ch >= 65 && *ch <= 90)  // Check if the character is an uppercase letter
        index = (*ch - 'A');  
    else if (*ch >= 97 && *ch <= 122)  // Check if the character is a lowercase letter
        index = (*ch - 'a'); 
    else  // Handle case for non-alphabetical characters
        index = 26;  

    return index;  
}

// Function to check if a file has already been updated
int check_file_updated(const char *filename,filenode *dupli_filename)
{
    // Loop through the duplicate filename list
    while (dupli_filename)
    {
        // Compare the current filename in the list with the provided filename
        if (strcmp(dupli_filename->data, filename) == 0)
            return FAILURE;  // Return FAILURE if the filename is found in the list

        // Move to the next node in the list
        dupli_filename = dupli_filename->link;
    }

    // Return SUCCESS if the filename is not found in the list
    return SUCCESS;
}
