/*Name:G.Haritha
Date:25/11/24
Description:inverted search update file.*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"

// Function to search for a word in the database
int search_database(mainlist *hashtable[], const char *word)
{
    // Variable to count non-NULL entries in the array
    int display_count = 0;  
    int i = 0;

    // Loop through the array to count non-NULL entries
    for (i = 0; i < 27; i++)
    {
        if (hashtable[i] != NULL)
        display_count++;
    }

    // check array empty or not
    if (display_count == 0)
        return 2;

    int flag = 0;  // Flag to indicate if the word was found

    // Loop through the array to search for the word
    for (i = 0; i < 27; i++)
    {
        mainlist *temp = hashtable[i];  // Pointer to traverse the mainlist

        // Loop through the mainlist nodes
        while (temp)
        {
            // Check if the current word matches the search word
            if (strcasecmp(temp->word, word) == 0)
            {
                flag = 1;  // Set flag to indicate the word was found
                printf("The word '%s' is present in %d files\n", word, temp->file_count);

                sublist *traverse = temp->sublink;  // Pointer to traverse the sublist

                // Loop through the sublist nodes
                while (traverse)
                {
                    // Print the filename and word count
                    printf("%s -> %d times\n", traverse->filename, traverse->word_count);
                    traverse = traverse->sublink;  // Move to the next sublist node
                }
                break;  // Exit the loop if the word is found
            }
            temp = temp->mainlink;  // Move to the next mainlist node
        }

        // If the word was found, print a newline and return SUCCESS
        if (flag)
        {
            printf("\n\n");
            return SUCCESS;
        }
    }

    // Return FAILURE if the word was not found
    return FAILURE;
}